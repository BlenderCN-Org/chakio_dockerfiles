import threading

class Context(object):

    def __init__(self):
        self.isNeedActivation = False

class Process(object):
    gCount=0
    gCondition = threading.Condition()
    FLAG_STATE = 0x40000000

    @staticmethod
    def g_enter():
        with Process.gCondition:
            Process.gCount += 1

    @staticmethod
    def g_exit():
        with Process.gCondition:
            Process.gCount -= 1
            if(Process.gCount == 0):
                Process.gCondition.notifyAll()

    @staticmethod
    def waitEndForAll():
        with Process.gCondition:
          while not Process.gCount <= 0:
            Process.gCondition.wait(1)

    def __init__(self):
        self.refCount = 0
        self.lock = threading.Lock()
        self.local = None

    def isNeedActivation(self):
        if(self.local == None):
            return True
        if(not hasattr(self.local,'context')):
            return True
        return self.local.context.isNeedActivation

    def setNeedActivation(self,mode):
        if self.isNeedActivation() != mode:
            self.context().isNeedActivation = mode

    def context(self,generate=True):
        if not generate:
            if self.local == None or not hasattr(self.local,'context'):
                return None
        if(self.local == None):
            self.local = threading.local()
        if(not hasattr(self.local,'context')):
            self.local.context = Context()
        return self.local.context

    def setContext(self,ctx):
        if(self.local == None):
            self.local = threading.local()
        self.local.context = ctx

    def enter(self):
        if not self.isNeedActivation():
            return
        active=False
        with self.lock:
            self.refCount += 1
            active = (self.refCount == 1)
        if active:
            self.g_enter()
            self.on_active()

    def exit(self):
        if not self.isNeedActivation():
            return
        inactive=False
        with self.lock:
            self.refCount -= 1
            inactive = (self.refCount == 0)
        if inactive:
            self.on_deactive()
            self.g_exit()

    def keepActive(self):
        active=False
        with self.lock:
            self.refCount |= self.FLAG_STATE;
            active = (self.refCount == self.FLAG_STATE)
        if active:
            self.g_enter()
            self.on_active()

    def resetActive(self):
        inactive=False
        with self.lock:
            self.refCount &= ~self.FLAG_STATE
            inactive = (self.refCount == 0)
        if inactive:
            self.on_deactive()
            self.g_exit()

    def on_active(self):
        pass

    def on_deactive(self):
        pass
