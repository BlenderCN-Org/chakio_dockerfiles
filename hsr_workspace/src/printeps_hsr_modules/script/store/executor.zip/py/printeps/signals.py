# coding: utf-8
#

class Observer:
    def __init__(self):
        self.handlers = {}

    def on(self,name,handler):
        if name not in self.handlers:
            self.handlers[name]=set([handler])
        else:
            self.handlers[name].add(handler)

    def remove(self,name,handler):
        if name in self.handlers:
            self.handlers[name].remove(handler)

    def trigger(self,name,arg):
        if name in self.handlers:
            handlers = list(self.handlers[name])
            for p in handlers:
                p(name,arg)

observer = Observer()
def default_observer():
    global observer
    return observer
