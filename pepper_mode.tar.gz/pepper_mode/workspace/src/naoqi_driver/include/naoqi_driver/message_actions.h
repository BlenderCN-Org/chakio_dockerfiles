#ifndef MESSAGE_ACTIONS_H
#define MESSAGE_ACTIONS_H

namespace naoqi
{
namespace message_actions
{

enum MessageAction
{
  PUBLISH,
  RECORD,
  LOG
};

}

}


#endif
