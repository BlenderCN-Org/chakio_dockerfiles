
import Queue
import threading

class ThreadQueue:

    def __init__(self):
        self.queue = Queue.LifoQueue()
        self.threads = []
        self.isAbort = False

    def start(self,numthread):
        for i in range(numthread):
            t = threading.Thread(target=self.process)
            t.daemon = True
            t.start()
            self.threads.append(t)

    def stop(self):
        self.queue.join()
        self.isAbort = True
        for t in self.threads:
            self.queue.put(None)
        for t in self.threads:
            t.join()

    def push(self,cmd):
        self.queue.put(cmd)

    def process(self):
        while not self.isAbort:
            p = self.queue.get()
            if p != None:
                p()
            self.queue.task_done()

threadQueue = ThreadQueue()

def push(cmd):
    threadQueue.push(cmd)

def start(numthread):
    threadQueue.start(numthread)

def stop():
    threadQueue.stop()


import os,signal,sys
import rospy

child_pid = -1

def catch_sig(sig, frame):
    assert child_pid > 0
    rospy.signal_shutdown("Interrupted by the signal")
    print >> sys.stderr, "Interrupted by the signal (mom)"
    print >> sys.stderr, "Killing %d"%child_pid
    os.kill(child_pid, signal.SIGKILL)
    sys.exit(1)

def set_sig_handlers():
    signal.signal(signal.SIGINT,  catch_sig)
    signal.signal(signal.SIGTERM,  catch_sig)
    signal.signal(signal.SIGHUP,  catch_sig)
    signal.signal(signal.SIGQUIT, catch_sig)

def patch_thread_interrupt():
    global child_pid
    child_pid = os.fork()
    if child_pid == -1:
        raise "Failed to fork"
    if child_pid > 0:
        set_sig_handlers()
        os.wait()
        sys.exit(0)


if __name__=='__main__':
    start(10)
    global p;p=0
    def proc():
        global p;p=p+1
        print "dump %d"%p
    push(proc)
    push(proc)
    push(proc)
    push(proc)
    stop()
