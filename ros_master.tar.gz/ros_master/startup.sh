#roslaunch ros_master master.launch
#exit