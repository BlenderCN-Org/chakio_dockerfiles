#import exceptions

class PrintepsException(Exception):
    pass;


class SkipException(PrintepsException):
    def __init__(self,value,Name=None):
        self.checkname = Name
        self.value = value

class ProcessException(PrintepsException):
    def __init__(self,original):
        self.original=original

class ReturnException(PrintepsException):
    def __init__(self,result):
        self.result=result
