import rospy
import threading

rosspin_thread = None

def process():
    rospy.spin()


def start():
    rospy.init_node("printeps",anonymous=True)
    global rosspin_thread
    rosspin_thread = threading.Thread(target=process)
    rosspin_thread.start()

def stop():
    rospy.signal_shutdown("normally exited")
    pass
